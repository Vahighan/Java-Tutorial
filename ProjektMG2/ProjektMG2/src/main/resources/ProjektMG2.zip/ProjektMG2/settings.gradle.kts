rootProject.name = "ProjektMG2"

